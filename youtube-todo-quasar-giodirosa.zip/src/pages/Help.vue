<template>
 <div>
   <q-page class="q-pa-lg">
     <h5 class="q-mt-none">Help</h5>
   <section>
     <p class="parrafoHelp">
       Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique modi sequi beatae fuga illo laborum rerum magni ipsum dicta consectetur harum ullam vel aut quisquam laudantium quas, doloribus totam corporis.
       Praesentium optio, obcaecati deserunt libero velit possimus sunt voluptatum harum deleniti minus laudantium illum illo nihil nesciunt numquam. A quo quisquam sequi ut ea quod corrupti adipisci id natus numquam.
       Repudiandae, odit fugiat quos magni ducimus expedita ipsum, at quisquam exercitationem cupiditate corporis odio recusandae fuga eaque consequatur laborum. Nemo voluptates fugit repellat aut eveniet id! Ab, voluptas quibusdam. Quidem?
       Voluptate, unde aperiam! Tempore, tempora accusantium nemo sunt obcaecati placeat a, maxime sapiente, magnam dolorem quidem assumenda. Repudiandae iste sint doloremque esse, consequatur labore tempore eius atque expedita rem? Laborum?
       A odit molestiae deserunt omnis tempora? Optio quisquam officia veritatis odit, architecto nihil, voluptatem aut asperiores corrupti iusto earum officiis neque quia mollitia ut quidem ea. Adipisci dolorem eligendi quam.
       Autem cumque quia deleniti quisquam quae minima nemo labore, officiis laborum iusto facilis beatae ipsa nobis magnam quam non, accusamus et voluptatibus consequuntur ad in vel odit earum ab! Perferendis?
       Repellendus qui unde natus maiores fuga eligendi sit, inventore fugiat blanditiis porro necessitatibus magnam rem earum, vel ab architecto aliquam dolorem laborum neque recusandae quaerat voluptas explicabo? Dolores, harum tempora?
       Saepe tempora at architecto voluptatum magni doloremque excepturi porro, quibusdam nulla assumenda. Temporibus placeat animi deserunt quia porro! Vitae possimus minima obcaecati pariatur quaerat voluptatum reprehenderit sed id voluptates corporis!
       Expedita sunt tempora dicta eos magni deserunt asperiores explicabo architecto saepe. Aut, saepe facilis! Architecto nemo ea voluptas molestias consequatur libero aut exercitationem. Saepe blanditiis eius vitae, quaerat molestias tempore!
       Animi libero accusamus at quae quaerat fugit! Rerum, pariatur non! Aliquid, inventore nisi culpa numquam, voluptatibus minima, fuga illo possimus necessitatibus id excepturi dolores. Voluptates praesentium quod animi impedit quis!
       Illo animi aliquam id, quis ipsam voluptate impedit autem facilis blanditiis itaque, eos similique quasi corrupti eum? In asperiores provident neque nihil, consequatur, possimus ipsum voluptatem, officia obcaecati nisi rerum.
       Alias assumenda modi, sequi error inventore minima cum illo reprehenderit saepe, facilis similique velit ab numquam deleniti. Amet, laudantium ab. Fugiat aut reiciendis dolorem quis dignissimos mollitia enim, earum voluptatibus!
       Aut mollitia vitae, iste assumenda molestias iure culpa? Corrupti assumenda, repellat aliquam ratione repudiandae veniam excepturi iusto, voluptates praesentium dicta, earum esse quam eos laudantium laborum molestias error! Repellendus, nihil?
       Repudiandae et nostrum optio autem facere hic accusantium asperiores, incidunt provident tempora eveniet odit sequi ratione molestiae suscipit ex omnis ea animi, dolorum at. Maxime optio facilis culpa facere nihil.
       Hic eveniet vero temporibus placeat cumque vitae quis, quidem quae non reiciendis magnam a harum doloremque autem deserunt adipisci ea voluptates neque dolorum omnis blanditiis culpa. Quos, ducimus eligendi! Iusto?
       Debitis quo eum molestias architecto dolor soluta sapiente atque dicta, neque modi temporibus deleniti assumenda. Vel laborum officia atque dolorem? Accusamus vel quis eum eligendi corporis, sed quisquam fugiat temporibus!
       Adipisci dignissimos, doloribus eius nihil, ipsa dicta unde commodi, exercitationem iusto recusandae quos dolorem officia voluptas rem repudiandae quia non nam delectus similique ut necessitatibus accusamus praesentium culpa voluptates. Aliquid!
       Nihil nobis repellendus autem dolores. Ex nemo sit veniam repellendus dolorum ipsam! Veritatis eos recusandae sequi harum nulla, libero, voluptatem minima quidem commodi aliquid, numquam necessitatibus odio placeat illo repellat?
       Iste, optio! Libero excepturi vel itaque corporis quis. Ipsa enim nemo corporis impedit, repudiandae modi nulla asperiores eligendi odio nam voluptate consequatur dolores distinctio totam delectus sint eius? Harum, fugiat.
       Perferendis tenetur ipsum deserunt quod exercitationem, enim maxime labore doloremque, esse libero reiciendis minima eum nisi culpa excepturi animi error illum assumenda! Velit, nemo ducimus fuga distinctio rerum alias omnis!
       Cupiditate ad quibusdam debitis. Esse delectus officiis tenetur sit aperiam vitae velit, ut consequuntur quibusdam quis. Odio qui facilis aliquid minus officiis quidem aut expedita. Architecto hic vero velit sunt.
       Est porro, laudantium tempore exercitationem provident minus assumenda ad? Quam suscipit fuga, sit aut blanditiis quis asperiores necessitatibus, in sed tempora fugit. Optio molestias corporis sit perferendis labore nulla nisi!
       Animi, iusto neque. Labore architecto illum nobis similique, et velit non incidunt error, iure ipsa suscipit voluptate cum ex quam numquam asperiores! Similique dolores doloribus obcaecati id mollitia molestiae natus!
       Accusantium, id? Tempore rem quas in quidem minus necessitatibus voluptatibus dignissimos aperiam vero tempora, laborum nulla atque temporibus. Optio nihil, praesentium laudantium eaque totam tempore. Corrupti adipisci quo voluptatibus id?
       Libero cum earum aliquid quaerat? Vero voluptatum voluptatibus provident eaque aspernatur. Illo perferendis pariatur soluta sit, possimus amet ratione labore explicabo voluptatibus porro ducimus cumque eum, ipsam quaerat eveniet? Praesentium?
       Accusamus, numquam accusantium. Adipisci iusto totam suscipit quod maxime voluptatem accusantium ducimus deserunt, qui eum, ratione vel amet quis laboriosam recusandae saepe distinctio facere maiores illo ea nemo fugiat nesciunt?
       Numquam praesentium tenetur excepturi dolores sequi itaque asperiores dolor! Dignissimos atque officia, ullam nam necessitatibus quasi ipsum odit voluptatum repudiandae facere error, excepturi illo, nesciunt culpa tempora quibusdam? Rerum, corrupti.
       Quasi quis aliquam temporibus debitis laudantium illo repellendus fugiat deserunt. Ut eum dignissimos impedit vero delectus molestias natus minima fugiat. Incidunt aperiam earum quibusdam tempore doloremque, quia assumenda blanditiis repellendus.
       Corrupti, aperiam ullam maxime blanditiis inventore fugiat a, doloribus minima eligendi in voluptatibus dignissimos iure aut, nostrum sed deleniti quidem dolor nulla! Ut laborum ab eligendi officiis provident sapiente quas!
       Eveniet magni porro, tempore minima delectus in iusto aperiam aliquid doloremque consequuntur labore, deleniti voluptas quidem error corporis culpa incidunt corrupti enim iure nostrum alias ipsum saepe! Doloribus, illo iure.
       Saepe, illo sequi in ratione nulla maxime delectus incidunt dolor repellat odio, cum est? Nam numquam assumenda molestias non optio unde ratione sit illum, itaque explicabo? Totam, veniam iste! Alias!
       Ea labore dolore accusamus aut quibusdam. Vero voluptatem voluptatum maiores rem enim? Et, numquam! Dolore provident aspernatur sit obcaecati iusto excepturi, impedit suscipit unde quas, ab architecto vitae blanditiis ipsam.
       Aliquam incidunt ipsa laboriosam. Corporis autem necessitatibus ea, dicta quidem nihil consectetur iusto, neque eos reprehenderit error, molestias ad minima praesentium tempora animi aperiam sunt? Nobis aspernatur tenetur ipsam quidem.
       Dignissimos, placeat consequatur, facere corrupti obcaecati dolorum saepe labore quisquam assumenda a debitis laudantium. Corporis officiis accusamus, quam eveniet pariatur, illum cumque vero quaerat doloribus officia aliquid quod voluptas tempore.
       Porro hic ipsa labore voluptatibus corrupti aut eveniet possimus omnis accusantium impedit deleniti, error recusandae eligendi soluta veritatis veniam dolorem? Dolore quia quae accusamus, tempora soluta pariatur modi sunt esse!
       Tenetur rerum consequuntur dignissimos cumque ipsa qui facere magni aperiam cupiditate? Maxime quod repudiandae corporis. Debitis, voluptatum accusantium modi recusandae veritatis commodi aperiam nostrum ad velit, dolore adipisci culpa excepturi.
       Provident minima autem aliquid impedit qui et nesciunt corrupti placeat, consectetur odio ut magni eius tempore facere veniam nam iusto magnam adipisci temporibus doloribus ullam vero iure molestiae veritatis? Vitae?
       Rem labore harum nostrum minima, modi quae, ipsa voluptates fugiat nam qui id ipsam totam dolor. Aliquam obcaecati voluptas accusamus at vero eligendi quaerat ipsam, temporibus provident qui mollitia atque.
       Eius at voluptate commodi nesciunt asperiores possimus optio voluptas. Quis est, officia facilis magni possimus temporibus distinctio ducimus, commodi et obcaecati quasi, modi odit! Veniam natus adipisci minima eum officia!
       Ut in reiciendis saepe, vitae quisquam ipsa voluptates vero, similique porro totam distinctio incidunt, sit eveniet. Quis eum, est, voluptatum perferendis sed temporibus recusandae commodi officia ipsum, voluptatem fugiat odio?
       Corrupti dolorem quidem quas doloremque deserunt officia, id temporibus eveniet a aliquam ipsa perspiciatis labore et vel? Enim odio tenetur, vel eligendi ullam eveniet nihil, repellat optio hic suscipit culpa.
       Iure natus laboriosam nam tempora culpa soluta modi qui ducimus sunt vero, beatae id facere at, omnis placeat. Quis delectus laborum mollitia illo accusantium itaque dolorum hic voluptates ipsum quos?
       Nulla illo consequuntur sit in culpa totam dolores. Expedita vitae pariatur quae quibusdam qui quos consequatur tempora cumque a? Expedita, neque? Odit omnis accusamus quibusdam maxime alias vitae, iure consectetur.
       Nobis nam quae quod dicta atque, ducimus aliquid quisquam consectetur. Distinctio, at! Voluptates expedita cumque, quisquam aspernatur doloribus sequi labore nemo inventore porro saepe ad repudiandae iusto, beatae nihil rerum.
       Ut beatae illum, ullam quas aspernatur quae optio quos laborum modi dolorum, dolores omnis quisquam. Explicabo, veritatis deserunt magni placeat neque beatae aliquid in repellat fugiat repellendus! Iste, minus soluta!
       Dolores vero molestias unde veniam eum? Quos repellendus et exercitationem beatae placeat nobis perferendis. Unde suscipit sit expedita vel eum voluptatibus veniam, sunt voluptatum saepe mollitia! In aliquid dolore accusantium.
       Ipsa ea tempora, tenetur odio velit minima suscipit esse dolore officia neque laboriosam labore rerum, dolor necessitatibus adipisci, illum cumque aut iure ullam impedit facere nihil sunt quae. Quidem, sapiente.
       Unde eos facere a, voluptates eum ducimus nam libero eligendi maxime ut voluptatem reiciendis, doloremque inventore dolorem dolore, quas dolores nesciunt soluta impedit nemo omnis nobis vero tenetur. Inventore, quam.
       Aliquam quasi nesciunt numquam, omnis provident iste temporibus nulla ducimus, nisi sapiente esse magnam in minus illo assumenda corrupti facere sint. Provident error adipisci magnam eaque ullam, officiis quidem omnis.
       Cupiditate nisi iure corrupti nemo architecto reprehenderit? Blanditiis, sunt. Error, provident et laudantium deleniti recusandae aspernatur dolorem modi nulla placeat ea repellendus pariatur quae delectus incidunt distinctio commodi dicta perferendis?
     </p>
   </section>
   </q-page>
 </div>
</template>


<style lang="scss" scoped>
// .help{
//   margin: 0px 20px;
// }

// .parrafoHelp{
//   padding: 0px 20px;
//   padding: 0px;
// }

</style>